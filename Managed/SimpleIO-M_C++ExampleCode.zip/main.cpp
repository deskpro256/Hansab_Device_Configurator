#include <stdlib.h>
#include <stdio.h>

using namespace System;
//STEP 1:  
//   Add the DLL as a reference to your project through "Project" -> "Add Reference" 
//   menu item within Visual Studio 
using namespace SimpleIO;		//<---- Need to include this namespace


int main() 
{ 
    //Variables 
    const unsigned int mcp2200_VID = 0x04D8;   //VID for MCP2200 
    const unsigned int mcp2200_PID = 0x00DF;   //PID for MCP2200 
    bool isConnected = false;                //Connection status of MCP2200 
  
    //STEP 2: Make function call using class name 
    //Initialize the MCP2200 
    SimpleIOClass::InitMCP2200(mcp2200_VID, mcp2200_PID); 
    //Check connection status 
    isConnected = SimpleIOClass::IsConnected(); 
    if (isConnected == true) 
    { 
        printf("The device is connected.\n"); 
    } 
    else 
    { 
        printf("The device is NOT connected.\n"); 
    }  
	return 0;
}